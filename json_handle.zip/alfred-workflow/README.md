# JSON Handle Alfred Workflow

这是一个Alfred工作流，可以快速打开JSON Handle网页并自动读取剪贴板内容。

## 功能特性

- 🚀 快速触发：输入 `json` 即可启动
- 📋 智能读取：使用现代剪贴板API直接读取剪贴板内容
- 🌐 直接打开：自动在默认浏览器中打开JSON Handle网页
- ⚡ 无缝体验：一键完成复制→打开→读取的完整流程
- 🔒 无长度限制：支持任意大小的JSON数据（MB级别）
- 🛡️ 更安全：敏感数据不会出现在URL中

## 技术方案

### 新方案（v2.0）- 剪贴板API
- **触发方式**：URL参数 `?from=alfred`
- **数据传输**：浏览器剪贴板API直接读取
- **优势**：
  - ✅ 无URL长度限制
  - ✅ 支持任意大小的JSON（MB级别）
  - ✅ 更安全（数据不经过URL）
  - ✅ 更快速（无需编码/解码）
  - ✅ 更可靠（避免特殊字符问题）

### 旧方案（v1.0）- URL参数 ❌
- **问题**：URL长度限制（IE/Chrome: 2,083字符）
- **限制**：只能处理小型JSON数据
- **已废弃**：不推荐使用

## 安装方法

### 方法一：直接导入（推荐）

1. 下载 `JSON Handle.alfredworkflow` 文件
2. 双击文件，Alfred会自动导入工作流
3. 确认导入即可使用

### 方法二：手动创建

1. 打开Alfred Preferences（偏好设置）
2. 点击 "Workflows" 标签
3. 点击左下角的 "+" 按钮，选择 "Blank Workflow"
4. 填写工作流信息：
   - Name: `JSON Handle`
   - Description: `快速打开JSON Handle网页并自动读取剪贴板内容`
   - Bundle Id: `com.jsonhandle.workflow`

5. 添加触发器：
   - 右键点击画布，选择 "Inputs" → "Keyword"
   - Keyword: `json`
   - Title: `JSON Handle`
   - Subtitle: `打开JSON Handle并自动读取剪贴板内容`
   - 取消勾选 "with space"

6. 添加脚本动作：
   - 右键点击画布，选择 "Actions" → "Run Script"
   - Language: `/bin/bash`
   - 将以下脚本粘贴到脚本框中：

```bash
#!/bin/bash

# 构建简化的URL（只传递触发标识）
base_url="http://antnluservice1.inc.alipay.net/json_handle"
full_url="${base_url}?from=alfred"

# 打开浏览器
open "$full_url"
```

7. 连接触发器和脚本：
   - 将触发器的输出连接到脚本动作的输入

## 使用方法

1. **复制JSON内容**：将需要处理的JSON内容复制到剪贴板
2. **启动Alfred**：按 `Cmd + Space`（或你设置的快捷键）
3. **输入触发词**：输入 `json` 并按回车
4. **自动处理**：
   - 浏览器自动打开JSON Handle网页
   - 网页检测到来自Alfred的访问
   - 自动调用剪贴板API读取数据
   - 显示"已自动读取剪贴板内容"提示

## 使用场景

- 📊 **大型API响应**：处理MB级别的API返回数据
- 🔍 **复杂日志分析**：处理包含大量JSON的日志文件
- 📝 **数据验证**：验证任意大小的JSON格式
- 🛠️ **JSON修复**：自动修复各种JSON格式错误
- 🌳 **深度数据探索**：以树形结构查看复杂的嵌套JSON

## 系统要求

- **macOS**：支持Alfred的任意版本
- **浏览器**：现代浏览器（Chrome、Firefox、Safari、Edge）
- **HTTPS**：需要HTTPS环境才能使用剪贴板API
- **权限**：浏览器需要剪贴板读取权限

## 注意事项

1. **HTTPS要求**：剪贴板API需要HTTPS环境，HTTP环境下会降级到手动粘贴
2. **权限授权**：首次使用时浏览器会询问剪贴板读取权限，请点击"允许"
3. **数据安全**：剪贴板内容直接在浏览器中处理，不经过网络传输
4. **兼容性**：所有现代浏览器都支持剪贴板API

## 故障排除

### 工作流不响应
- 检查Alfred是否有权限访问剪贴板
- 确认触发词 `json` 没有与其他工作流冲突

### 网页无法打开
- 检查网络连接
- 确认URL地址是否正确
- 尝试手动访问网页

### 剪贴板内容未读取
- 确认剪贴板中有内容
- 检查浏览器是否授予了剪贴板读取权限
- 确认网站使用HTTPS协议
- 查看浏览器控制台是否有错误信息

### HTTP环境下的替代方案
如果在HTTP环境下使用，可以：
1. 点击网页上的"读取剪贴板"按钮
2. 或者手动粘贴JSON内容到输入框

## 更新日志

### v2.0.0
- 🔄 重大更新：改用剪贴板API方案
- ✅ 移除URL长度限制
- ✅ 支持任意大小的JSON数据
- ✅ 提升安全性和可靠性
- ✅ 简化工作流脚本

### v1.0.0
- ❌ 初始版本（已废弃）
- ❌ 使用URL参数传递数据
- ❌ 受URL长度限制影响

## 技术实现

- **触发器**：Alfred Keyword Input
- **脚本语言**：Bash（极简化）
- **数据传输**：浏览器剪贴板API
- **浏览器调用**：macOS `open` 命令
- **前端接收**：JavaScript Clipboard API

## 贡献

如果你有任何建议或发现了问题，欢迎提出反馈！ 